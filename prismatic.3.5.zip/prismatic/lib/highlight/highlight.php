<?php // Prismatic - Highlight

if (!defined('ABSPATH')) exit;
