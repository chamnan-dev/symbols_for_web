<?php // Prismatic - Plain

if (!defined('ABSPATH')) exit;
